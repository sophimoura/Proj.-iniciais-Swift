//
//  API_testeApp.swift
//  API.teste
//
//  Created by user on 06/10/23.
//

import SwiftUI

@main
struct API_testeApp: App{
    var body: some Scene{
        WindowGroup {
            ContentView()
        }
    }
}

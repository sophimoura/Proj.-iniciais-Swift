
import SwiftUI

struct ContentView: View {
    @State private var selecteFoods: [String] = []
    let comidas = ["Macarrão", "Lasanha", "Burrito", "Sorvete"]

    var body: some View {
        NavigationView {
            List(comidas, id: \.self) { comidas in
                PhotoRow(comidas:comidas, isSelected: self.selecteFoods.contains(comidas)) {
                    self.toggleSelection(comidas)
                }
            }
            .navigationBarItems(trailing:
                Button(action: {
                    self.deleteSelecteFoods()
                }) {
                    Text("Próximo")
                }
                .disabled(selecteFoods.isEmpty)
            )
        }
    }

    private func toggleSelection(_ comidas: String) {
        if let index = selecteFoods.firstIndex(of: comidas) {
            selecteFoods.remove(at: index)
        } else {
            selecteFoods.append(comidas)
        }
    }

    private func deleteSelecteFoods() {
     
        print("Fotos selecionadas: \(selecteFoods)")
        selecteFoods.removeAll()
    }
}

struct PhotoRow: View {
    var comidas: String
    var isSelected: Bool
    var toggleSelection: () -> Void

    var body: some View {
        HStack {
            Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                .onTapGesture {
                    self.toggleSelection()
                }
            Text(comidas)
        }
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


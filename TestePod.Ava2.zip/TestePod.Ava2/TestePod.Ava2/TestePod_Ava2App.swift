//
//  TestePod_Ava2App.swift
//  TestePod.Ava2
//
//  Created by user on 08/12/23.
//

import SwiftUI

@main
struct TestePod_Ava2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

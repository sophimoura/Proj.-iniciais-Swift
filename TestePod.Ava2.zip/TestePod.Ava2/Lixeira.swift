//
//  Lixeira.swift
//  TestePod.Ava2
//
//  Created by user on 08/12/23.
//

import Foundation
import SwiftUI

struct LixeiraView: View {
    var selectedPhotos: [String]
    
    var body: some View {
        VStack {
            Text("Itens na Lixeira:")
                .font(.title)
                .padding()
            
            List(selectedPhotos, id: \.self) {_ in
            }
        }
    }
    
    private func deleteSelectedPhotos() {
        print("Fotos selecionadas: \(selectedPhotos)")
        
        if !selectedPhotos.isEmpty {
            let lixeiraView = LixeiraView(selectedPhotos: selectedPhotos)
            let hostingController = UIHostingController(rootView: lixeiraView)
            
            if let rootViewController = UIApplication.shared.windows.first?.rootViewController {
                rootViewController.present(hostingController, animated: true, completion: nil)
            }
        }
        
    }
}

import SwiftUI

struct ContentView: View {
    @State private var selectedComidas: Set<String> = []
    @State private var searchText = ""

    var body: some View {
        NavigationView {
            List {
                ForEach(comidas, id: \.nome) { comida in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(comida.nome.capitalized)
                                .font(.system(size: 20))
                                .font(.headline)

                            Spacer()

                            HStack {
                                Spacer()
                                Button(action: {
                                    toggleSelection(comida)
                                }) {
                                    Image(systemName: selectedComidas.contains(comida.nome) ? "checkmark.circle.fill" : "plus.circle")
                                        .font(.system(size: 30))
                                        .foregroundColor(selectedComidas.contains(comida.nome) ? .green : .blue)
                                }
                            }
                        }
                    }
                    .padding()
                }
            }
            .padding()
            .searchable(text: $searchText)
            .navigationTitle("Produtos")
            .navigationBarItems(trailing: NavigationLink("Avaliar", destination: EvaluationView(selectedComidas: $selectedComidas)))
        }
    }

    private var comidas: [(nome: String, imagem: String)] {
        // Defina sua lista de comidas aqui
        return [("Comida1", "imagem1"), ("Comida2", "imagem2"), ("Comida3", "imagem3")]
    }

    private func toggleSelection(_ comida: (nome: String, imagem: String)) {
        if selectedComidas.contains(comida.nome) {
            selectedComidas.remove(comida.nome)
        } else {
            selectedComidas.insert(comida.nome)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

//
//  TesteFotoLixoApp.swift
//  TesteFotoLixo
//
//  Created by user on 08/12/23.
//

import SwiftUI

@main
struct TesteFotoLixoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

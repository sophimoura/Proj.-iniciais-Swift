import Foundation

class Contato {
    var nome: String
    var telefone: String
    var email: String
   
    init(nome: String, telefone: String, email: String) {
        self.nome = nome
        self.telefone = telefone
        self.email = email
    }
}

class Agenda {
    var contatos: [Contato]
    
    init() {
        self.contatos = []
    }
    
    func adicionaContato(nome: String, telefone: String, email: String) {
        let contato = Contato(nome: nome, telefone: telefone, email: email)
        contatos.append(contato)
    }
    
    func removeContato(nome: String) {
        contatos = contatos.filter { $0.nome != nome }
    }
    
    func editaContato(nome: String, novoTelefone: String, novoEmail: String) {
        if let contato = contatos.first(where: { $0.nome == nome }) {
            contato.telefone = novoTelefone
            contato.email = novoEmail
        }
    }
    
    func listaContatos() {
        print("Lista de Contatos:")
        for contato in contatos {
            print("Nome: \(contato.nome), Telefone: \(contato.telefone), Email: \(contato.email)")
        }
    }
    func possuemNoNomeUmaPalavra(palavrasChave: String ) -> [Contato] {
        let resultados = contatos.filter { $0.nome.contains(palavrasChave)}
            return resultados
            
        }
    
    
        
    let minhaAgenda = Agenda()
        
        minhaAgenda.adicionaContato(nome: "Gabi", telefone: "123-456-7890", email: "gabi@email.com")
        minhaAgenda.adicionaContato(nome: "Lucas", telefone: "987-654-3210", email: "lucas@email.com")
        
        minhaAgenda.listaContatos()
        
        minhaAgenda.removeContato(nome: "Gabi")
        
        minhaAgenda.listaContatos()
        
        minhaAgenda.editaContato(nome: "Lucas", novoTelefone: "999-888-7777", novoEmail: "lumas.novo@email.com")
        
        minhaAgenda.listaContatos()
        
        let resultadosBusca = minhaAgenda.possuemNoNomeUmaPalavra(palavrasChave: "Ma")
    }

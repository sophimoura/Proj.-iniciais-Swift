//

//  ContentView.swift

//  candace007

//

//  Created by User on 12/09/23.

//



import SwiftUI



struct ContentView: View {

    var body: some View {

        ZStack {

            Color.blue

                .edgesIgnoringSafeArea(.all)

            VStack{

                Text ("OBJETIVO PRINCIPAL")

                    .font(.system(size: 44))

                    .foregroundColor(.white)

                    .bold()
                  
                
                   contentImages()
                    Text ("Desmascarar meus irmãos...")

                        .font(.headline)

                        .foregroundColor(.white)

                        .bold()

                    

                    Button{

                        

                    } label: {

                        Text("Avançar")

                        .font(.headline)

                        .foregroundColor(.blue)

                        .padding(.vertical, 10)

                        .padding(.horizontal, 10)

                        .background(Color.white)

                        .cornerRadius(50)

                        

                    }

                

            }

        }

    }

}



struct ContentView_previews: PreviewProvider {

    static var previews: some View {
        ContentView()

    }

}

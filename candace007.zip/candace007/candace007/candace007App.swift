//
//  candace007App.swift
//  candace007
//
//  Created by user on 15/09/23.
//

import SwiftUI

@main
struct candace007App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

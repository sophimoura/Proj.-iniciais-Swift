//
//  contentImages.swift
//  candace007
//
//  Created by user on 15/09/23.
//

import Foundation
import SwiftUI

struct contentImages: View{
    var body: some View{
      
        HStack{
            Image("candace")
            
                .resizable()
            
                .frame(width: 150, height: 150)
            
                .cornerRadius(10)
            
            
            
            VStack{
                XImageView("phineas")
                XImageView("ferb")
                
                
            }
            
        }
                
            }
            
        }
        
    
struct contentImages_previews: PreviewProvider {

    static var previews: some View {

        contentImages()

    }

}

//
//  TaskList_01App.swift
//  TaskList_01
//
//  Created by user on 10/10/23.
//

import SwiftUI

@main
struct TaskList_01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

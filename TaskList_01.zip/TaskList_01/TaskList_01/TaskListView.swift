//
//  TaskListView.swift
//  TaskList_01
//
//  Created by user on 10/10/23.
//

import SwiftUI

struct TaskListView: View {
    var body: some View {
        
        ZStack{
            
            Color.white
            
                .edgesIgnoringSafeArea(.all)
            
            VStack{
                
                Text("Lista de Tarefas")
                                
                    .font(.system(size: 35))
                
                    .offset(x: 0, y: -200)
                
                Button(action: {
                    
                }) {
                    
                    HStack(alignment: .center, spacing: 10) {
                        
                        Circle()
                        
                            .fill(Color.blue)
                        
                            .frame(width:20, height:20, alignment: .center)
                        
                            .offset(x:0,y: -200)
                        
                        Text("Varrer a varanda")
                            .font(.system(size: 20))
                        
                            .frame(maxWidth: 200, minHeight: 60)
                        
                            .background(Color.white)
                        
                            .cornerRadius(10)
                        
                            .shadow(color: Color.gray.opacity(0.6), radius: 5, x:2, y:7)
                        
                            .offset(x: 0, y: -200)
                    }
                    
                }
                
                Button(action: {
                    
                }) {
                    
                    
                    HStack(alignment: .center, spacing: 10) {
                        
                        Circle()
                        
                            .fill(Color.blue)
                        
                            .frame(width:20, height:20, alignment: .center)
                        
                            .offset(x:0,y: -200)
                        
                        Text("Regar as plantas")
                        
                            .font(.system(size: 20))
                        
                            .frame(maxWidth: 200, minHeight: 60)
                        
                            .background(Color.white)
                        
                            .cornerRadius(10)
                        
                            .shadow(color: Color.gray.opacity(0.6), radius: 5, x:2, y:7)
                        
                            .offset(x: 0, y: -200)
                    }
                }
                
                
                Button(action: {
                    
                }) {
                    
                    HStack(alignment: .center, spacing: 10) {
                        
                        Circle()
                        
                            .fill(Color.blue)
                        
                            .frame(width:20, height:20, alignment: .center)
                        
                            .offset(x:0,y: -200)
                        
                        Text("Trocar a terra do vaso")
                        
                        
                            .font(.system(size: 20))
                        
                            .frame(maxWidth: 200, minHeight: 60)
                        
                            .background(Color.white)
                        
                            .cornerRadius(10)
                        
                            .shadow(color: Color.gray.opacity(0.6), radius: 5, x:2, y:7)
                        
                            .offset(x: 0, y: -200)
                        
                    }
                    
                }
                
            }
            
        }
    }
}

struct TaskListView_Preview: PreviewProvider {
    
    static var previews: some View {
        
        TaskListView()
        
    }
    
}

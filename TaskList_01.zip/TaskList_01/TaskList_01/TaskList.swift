

import Foundation

import SwiftUI

struct TaskList{
    
    var list: [Task] = []
    
    mutating func adicionaTask(title: String, id: UUID, isDone: Bool){
        let novaTarefa = Task(id: id, title: title, isDone: isDone)
        list.append(novaTarefa)
    }
    
    mutating func removeTask(id: UUID){
        list = list.filter { $0.id != id }
        
    }
    
    mutating func concluirTask(id: UUID) -> Bool{
        list = list.filter { $0.id != id }
        return Bool(true)
    }
    
    
    mutating func desmarcarTask(id: UUID) -> Bool{
        list = list.filter { $0.id != id }
        return Bool(false)
        
    }
    
}









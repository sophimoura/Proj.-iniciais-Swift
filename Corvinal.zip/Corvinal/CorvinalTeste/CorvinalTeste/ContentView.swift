//
//  ContentView.swift
//  CorvinalTeste
//
//  Created by user on 15/09/23.
//
import Foundation
import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            
            
            
            Color.black
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 15){
                
                VStack{
                    Image("blue")
                    .offset(x:0, y:-0)
                }
                
                Text(" Welcome Revens! ")
                    .font(.system(size: 30))
                    .background(Color.blue.opacity(0.9))
                    .foregroundColor(.white)
                    .cornerRadius(20)
                    .offset(x: 0, y: -500)
              
                ContentImages()
                
                .offset(x: 0, y: -450)
                
                Image(systemName: "LogoCorvinal")
                    .foregroundColor(.accentColor)
        
                
            
                Button{
            }
            label:{
                    Text("TO ENTER")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding(.vertical, 10)
                    .padding(.horizontal, 10)
                    .background(Color.blue.opacity(0.9))
                    .cornerRadius(100)
                    .bold()
                    .offset(x:0, y:-650)
                
                  }
            }
           
        }
    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}

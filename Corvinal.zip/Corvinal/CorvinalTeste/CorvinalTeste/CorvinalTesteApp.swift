//
//  CorvinalTesteApp.swift
//  CorvinalTeste
//
//  Created by user on 15/09/23.
//

import SwiftUI

@main
struct CorvinalTesteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  XImageView.swift
//  CorvinalTeste
//
//  Created by user on 15/09/23.
//

import Foundation
import SwiftUI
struct XImageView: View{
    
    
    let imageName:String
    init(_ imageName: String) {
        self.imageName = imageName
        
    }
    var body: some View{
        ZStack{
            Image(imageName)
            
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
    
}

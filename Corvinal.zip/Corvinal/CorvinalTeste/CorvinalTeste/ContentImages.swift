//
//  ContentImages.swift
//  CorvinalTeste
//
//  Created by user on 15/09/23.
//

import Foundation
import SwiftUI
struct ContentImages: View{
    var body: some View{
        ZStack{
            
            HStack{
                
                Image("LogoCorvinal")
                
                    .resizable()
                    .frame(width: 300, height: 300)
                  
                 
                
            }
            
        }
        ZStack{
            
            HStack{
                
                Image("azul")
                
                    .resizable()
                
                    .frame(width: 400, height: 300)
                
                
            }
            
        }
        
    }
    
}
    
    struct ContentImages_previews: PreviewProvider {
        
        static var previews: some View {
            
            ContentImages()
        }
        
    }
    
    


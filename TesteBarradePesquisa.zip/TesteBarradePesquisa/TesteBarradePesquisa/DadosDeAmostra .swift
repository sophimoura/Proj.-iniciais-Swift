
import Foundation
public var listaDeComida = [
"Macarrão",
"Pizza",
"Lasanha"]

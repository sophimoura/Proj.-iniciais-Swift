//
//  TesteBarradePesquisaApp.swift
//  TesteBarradePesquisa
//
//  Created by user on 22/11/23.
//

import SwiftUI

@main
struct TesteBarradePesquisaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

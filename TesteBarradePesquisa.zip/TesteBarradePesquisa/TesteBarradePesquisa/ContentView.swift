
import SwiftUI


struct ContentView: View {
    private var listaDePratos = listaDeComida
    @State var searchText = ""
    
    var body: some View {
        NavigationView{
            List{
                ForEach(comidas, id: \.self){ comida in
                    HStack{
                        Text(comida.capitalized)
                        Spacer()
                    }
                }
            }
            
            .padding()
            
        }
        .searchable(text: $searchText)
        .navigationTitle("Produtos")
    }
    
    
    var comidas: [String] {
        let lcComidas = listaDePratos.map { $0.lowercased() }
        
        return searchText == "" ? lcComidas: lcComidas.filter {
            $0.contains(searchText.lowercased())
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct Song: Codable {
    let name: String
    let album: String
    let year: Int
}

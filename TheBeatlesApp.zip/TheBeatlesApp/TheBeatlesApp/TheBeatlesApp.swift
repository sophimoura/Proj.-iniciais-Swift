import SwiftUI

@main
struct TheBeatlesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

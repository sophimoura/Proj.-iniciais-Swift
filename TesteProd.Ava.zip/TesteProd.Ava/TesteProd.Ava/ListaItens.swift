import SwiftUI
struct Item {
    var id: UUID
    var nome: String
    var avaliacao: Int?
}

struct ListaItensView: View {
    @State private var itens: [Item] = [
        Item(id: UUID(), nome: "Item 1", avaliacao: nil),
        Item(id: UUID(), nome: "Item 2", avaliacao: nil),
    ]

    var body: some View {
        NavigationView {
            List(itens.indices, id: \.self) { index in
                NavigationLink(
                    destination: AvaliacaoView(item: $itens[index]),
                    label: {
                        Text(itens[index].nome)
                    }
                )
            }
            .navigationTitle("Lista de Itens")
        }
    }
}
struct AvaliacaoView: View {
    @Binding var item: Item

    var body: some View {
        VStack {
            Text("Avalie \(item.nome)")
            
        }
        .padding()
        .navigationBarTitle("Avaliação")
        .navigationBarItems(trailing:
            Button("Salvar") {
             
            }
        )
    }
}

struct ListaItensView_Previews: PreviewProvider {
    static var previews: some View {
        ListaItensView()
    }
}

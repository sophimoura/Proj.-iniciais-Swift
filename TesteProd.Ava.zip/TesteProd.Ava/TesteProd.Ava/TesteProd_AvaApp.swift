
import SwiftUI

@main
struct TesteProd_AvaApp: App {
    var body: some Scene {
        WindowGroup {
            
        }
    }
}

//
//  ArrayScreen.swift
//  09
//
//  Created by user on 19/09/23.
//

import SwiftUI
struct ErroCenário{
    let emoji: String
    let errorMenssage: String
    let id = UUID()
}
struct ArrayScreen: View {
    let erroCenários: [ErroCenário] = [
        ErroCenário(emoji:"😁",errorMenssage: "Erro: A variável 'não inciada não foi incializada. Tente inciciar com um valor."),
        ErroCenário(emoji:"🤪",errorMenssage: "Erro: O indíce está fora dos limites da matriz. Provavelmente você contou até 11 em vez de 10."),
        ErroCenário(emoji:"🚢",errorMenssage: "Chaves não correspondetes. Lembre-se abra chaves '{'precisa ter um fecha'}'."),
        ErroCenário(emoji:"🎬",errorMenssage: "Esqueceu de fechar as aspas. Lembre-se de fechar para não ficar confuso."),
        ErroCenário(emoji:"🐝",errorMenssage: "Erro divisão por zero. Nao é possível dividir nada por zero, mesmo na programação."),
        ErroCenário(emoji:"🥝",errorMenssage: "Se você está preso em um loop que não termina, seus personagens virtuais podem ficar tontos."),
    ]
    
    var body: some View {
        
        ScrollView{
            VStack(spacing: 10){
    
                ForEach(erroCenários, id: \.id){ erroCenário in
                    Text(erroCenário.emoji)
                        .font(.system(size: 50))
                        .foregroundColor(.white)
                        .background(Color.brown)
                        .clipShape(Circle())
                    
                    Text(erroCenário.errorMenssage)
                        .font(.headline)
                        .multilineTextAlignment(.center)
                        .padding()
                }
                .frame(maxWidth: .infinity, minHeight: 150)
                .background(Color.white)
                .cornerRadius(15)
                .shadow(color: Color.gray.opacity(0.6), radius: 5, x: 0, y:2)
                .padding(.init(top: 5, leading: 16, bottom: 5, trailing: 16))
                
            }
            
        }
    }
    
    
    
    struct ArrayScreen_Previews: PreviewProvider {
        static var previews: some View {
            ArrayScreen()
        }
    }
    
}

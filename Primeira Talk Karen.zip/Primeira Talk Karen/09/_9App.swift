//
//  _9App.swift
//  09
//
//  Created by user on 19/09/23.
//

import SwiftUI

@main
struct _9App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

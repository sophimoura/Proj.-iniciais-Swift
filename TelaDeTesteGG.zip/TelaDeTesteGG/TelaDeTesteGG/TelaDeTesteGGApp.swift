//
//  TelaDeTesteGGApp.swift
//  TelaDeTesteGG
//
//  Created by user on 24/11/23.
//

import SwiftUI

@main
struct TelaDeTesteGGApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

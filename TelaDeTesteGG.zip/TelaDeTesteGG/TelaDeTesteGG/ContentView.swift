//
//  ContentView.swift
//  TelaDeTesteGG
//
//  Created by user on 24/11/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        
        ContentImages()
        
        Button(){
        }
    label:{
        Text("LIBERAR")
            .font(.headline)
            .foregroundColor(.orange)
            .padding(.vertical, 10)
            .padding(.horizontal, 10)
            .background(Color.white)
            .cornerRadius(100)
            .bold()
            .offset(x:0, y:-650)
        
    }
        
    .padding()
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

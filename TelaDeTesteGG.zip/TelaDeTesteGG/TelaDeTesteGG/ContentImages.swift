//
//  ContentImage .swift
//  TelaDeTesteGG
//
//  Created by user on 24/11/23.
//

import Foundation
import SwiftUI
struct ContentImages: View{
    var body: some View{
        VStack{
            Image("Circulo")
            Image("Vector")
            Image("Logo")
           
        }
        }
    }

                
struct ContentImage: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

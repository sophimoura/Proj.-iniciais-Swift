//
//  RickAndMortyApp.swift
//  RickAndMorty
//
//  Created by user on 03/10/23.
//

import SwiftUI

@main
struct RickAndMortyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

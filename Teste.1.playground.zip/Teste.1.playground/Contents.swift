let nomes = ["Gabi","Mateus","Elis", "Carol", "Caio", "Lucas","Davi"]
let nome = [0]
let primeiraletra =  nome.filter

